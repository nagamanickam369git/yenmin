import React from 'react'
import Nav from './components/Nav'
import Mid from './components/Mid'
import Services from './components/Services'
import "./components/Style.css"
export default
  function App() {

  return (
    <div>
      <Nav />
      <Mid />
      <Services />
    </div >

  )
}

























































// import { BrowserRouter } from "react-router-dom";
// import UserOne from './whatsapp_clone/UserOne';
// import UserTwo from './whatsapp_clone/UserTwo';
// import Ui from './Email/Ui'
// import Admin from './Email/Admin'
// import Users from './Email/Users'
// import { Route, Routes } from "react-router-dom";

//Routers
/* <BrowserRouter>
<Routes>
  <Route key={'o'} path="/" element={<Ui />} ></Route>
  <Route key={'oo'} path="/admin" element={<Admin />} ></Route>
  <Route key={'ooo'} path="/users" element={<Users />} ></Route>
</Routes>
</BrowserRouter> */







    // <div>
    //   <BrowserRouter>
    //     <Routes>
    //       <Route key={'o'} path="/" element={
    //         <>
    //           <UserOne />
    //           <UserTwo />
    //         </>
    //       } ></Route>
    //       <Route key={'o'} path="/" element={<UserTwo />} ></Route>
    //       <Route key={'oo'} path="/UserOne" element={<UserOne />} ></Route>
    //       <Route key={'ooo'} path="/UserTwo" element={<UserTwo />} ></Route>

    //     </Routes>
    //   </BrowserRouter>

    // </div >
