import React from 'react'

export default function Nav() {
    return (
        <div className="">
            <nav>
                <ol>
                    <li><button className="li-btn"><a href="/" target="_blank">Free Counsulting </a><i
                        className="fa-solid fa-arrow-right"></i></button></li>
                    <li><a href="/" target="_blank">Contact Us</a></li>
                    <li><a href="/" target="_blank">About Us</a></li>
                    <li><a href="/" target="_blank">Case Studies</a></li>
                    <li><a href="/" target="_blank">Domains</a></li>
                    <li><a href="/" target="_blank">Services</a></li>
                    <li> <a href="/" target="_blank">Home</a> </li>
                </ol>
            </nav>
        </div>
    )
}
