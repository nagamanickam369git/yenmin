import React from 'react'
import lap from './pic/lap.png'
import { useState, useEffect } from 'react'
import axios from 'axios'
export default function Services() {

    const [midd, setmidd] = useState([])
    const [inputone, setinputone] = useState('')
    const [inputtwo, setinputtwo] = useState('')

    useEffect(() => {
        axios.get('http://localhost:5000/Task/midd').then((response) => {
            let content = response.data.data
            console.log('con', content);
            setmidd(content)
        })
    }, [])


    const sent = async () => {
        if (!!inputone && !!inputtwo) {

            let obj = { dataone: inputone, datatwo: inputtwo }
            await axios.post('http://localhost:5000/Task/new', { obj }).then((response) => {
                let content = response.data.data
                setmidd(content)
            })
            setinputone('')
            setinputtwo('')
        }
        else alert('please fill')
    }
    const edit = (id) => {

    }
    const del = async (id) => {
        let ids = id
   alert(ids)
        await axios.post(`http://localhost:5000/Task/del`, {  ids }).then(async(response) => {
            let content =await response.data.data
console.log('con',content);
                // setmidd(content)
        })
    }
    return (
        <div className="services">
            <b>OUR SERVICES</b>
            <h1>Services</h1>
            <div className='center'>
                <label htmlFor="">Heading</label>
                <input type="text" value={inputone} onInput={e => setinputone(e.target.value)} />
                <label htmlFor="">Content</label>
                <input type="text" value={inputtwo} onInput={e => setinputtwo(e.target.value)} />
                <button onClick={sent}>Add new</button>
            </div>



            <div className="con">
                {midd.length === 0 ? "" : midd.map((value, index) => {
                    return (
                        <>
                            <div key={index} className="cards">
                                <img className="lap" src={lap} alt="laptop" />
                                <h3>{value.jxsdata
                                    .dataone}</h3>
                                <p>{value.jxsdata.datatwo}</p>
                                <button onClick={() => { edit(value._id) }} >Edit </button>
                                <button onClick={() => { del(value._id) }} >delete</button>
                            </div>
                        </>
                    )
                })}


            </div>
        </div>
    )
}
