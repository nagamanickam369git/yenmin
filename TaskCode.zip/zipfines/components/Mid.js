import React from 'react'
import person from './pic/slider.jpg'
import banner from './pic/banner.png'
import { useEffect, useState } from 'react'
import axios from 'axios'

export default function Mid() {
    const [content, setcontent] = useState([])
    useEffect(() => {
        axios.get('http://localhost:5000/Task/content').then(async (response) => {
            let content = await response.data
         
            let data =[content]
            setcontent(data)

        })
    }, [])


    return (<>

        <div className="mid">
            <div className="icon-left">
                <i class="fa-solid fa-circle-chevron-left"></i>

            </div>


            {content.length === 0 ? <span>no data</span> : content.map((value, index) => {

              
                return (<>
                    <div key={index} className="contents">
                        <p className="it">{value.dataone}</p>
                        <p className="IT">{value.datatwo}</p>
                        <p className="sec-p">{value.datathree}</p>
                        <button className="it-btn"> Our Services</button>
                    </div>
                </>)

            })}
            <img className="person" src={person} alt="image" />
            <img className="banner" src={banner} alt="image" />
            <div className="icon-right">
                <i className="fa-solid fa-circle-chevron-right"></i>
            </div>
        </div>
    </>
    )
}
