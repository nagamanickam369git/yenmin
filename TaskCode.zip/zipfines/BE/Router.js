const express = require("express");
const router = express.Router();
const collection = require("./schema");
const mongoose = require("mongoose");


mongoose.set("strictQuery", false);
mongoose.connect("mongodb://127.0.0.1:27017/Task", (err, db) => {

    var Database = db
    if (err) throw err;
    console.log('DB Connection Success');

router.get('/content',async(req,response)=>{
    let content = await Database.collection('Task').findOne()
  await  response.json({'data':content})

})
router.get('/midd',async(req,response)=>{
    let data = await Database.collection('Task').find().toArray()
    
    let content =[]
        data.forEach(element => {
          
            if(element.jxsdata){             
                 content.push(element)
            }
        });
    
    
       await  response.json({'data':content})
})
router.post('/new',async(req,response)=>{
  let bodydata =await  req.body.obj
   await Database.collection('Task').insertOne({'jxsdata':{"dataone":bodydata.dataone,"datatwo":bodydata.datatwo}})
   let data = await Database.collection('Task').find().toArray()
let content =[]
    data.forEach(element => {
        if(element.jxsdata){
            content.push(element.jxsdata)
        }
    });


  await  response.json({'data':content})

})

router.post('/del',async(req,response)=>{
    let id=await req.body.ids
  
     await Database.collection('Task').deleteOne({'_id':`ObjectId(${id})`})
    let data = await Database.collection('Task').find().toArray()
    let content =[]
        data.forEach(element => {
            if(element.jxsdata){
                content.push(element.jxsdata)
            }
        });
    
    
      await  response.json({'data':content})

})


})
module.exports = router



























